This is a temporary fork of the JFresnel FSL-Sesame code as we
use a different Sesame version than JFresnel.  JFresnel was
once known as a part of the IsaViz project, thus the archaic
name sometimes seen in this fork.

You can find the JFresnel page here:

   http://jfresnel.gforge.inria.fr/

and the original source code is maintained through SVN here:

   svn://scm.gforge.inria.fr/svn/jfresnel/fsl-sesame

and is licensed under the LGPL.

This fork is on verion 0.6.5 code as of November 13, 2007.  It
will be obsoleted when our projects can harmonize on a version
of Sesame.

Many thanks to Emmanuel Pietriga for the code and to him and
The Nhan Luong for their Mavenization work, which makes this
fork simple to maintain.
