/*
 * Copyright Aduna (http://www.aduna-software.com/) (c) 2007.
 *
 * Licensed under the Aduna BSD-style license.
 */
package org.openrdf.http.webclient.repository.modify.remove;

import org.openrdf.http.webclient.StatementSpecification;

/**
 * @author Herko ter Horst
 */
public class RemovalSpecification extends StatementSpecification {

}
